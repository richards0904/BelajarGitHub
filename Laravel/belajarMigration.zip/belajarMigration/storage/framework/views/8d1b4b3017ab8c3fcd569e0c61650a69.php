<?php $__env->startSection('title', 'Halaman Mahasiswa'); ?>

<?php $__env->startSection('content'); ?>
<h2>Mahasiswa</h2>
    <table>
        <thead>
            <tr>
                <th>NPM</th>
                <th>Nama Mahasiswa</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $allmahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align: center"><?php echo e($item -> npm); ?></td>
                    <td style="text-align: center"><?php echo e($item -> nama_mahasiswa); ?></td>
                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SI41\Laravel\belajarMigration\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>