<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class MahasiswaController extends Controller
{
    public function insert(){
        $result = DB::insert('insert into mahasiswa(npm,nama_mahasiswa,tempat_lahir,tanggal_lahir,alamat,created_at) values (?,?,?,?,?,?)', [2125240044, 'Richard','Plg','2004-04-10','Sudirman',now()]);
        dump($result);
    }
    public function select(){
        $kampus = "Universitas Multi Data Palembang";
        $result = DB::select('select * from mahasiswa');
        // dump($result);
        return view('mahasiswa.index',['allmahasiswa' => $result,'kampus' => $kampus]);
    }
}
