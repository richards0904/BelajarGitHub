<?php

use App\Http\Controllers\ProdiController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/fakultas', function () {
    $kampus="Universitas MDP";
    $fakultas= ["Fakultas Ilkom","Fakultas Ilmu Ekonomi"];

    return view("fakultas.index",compact("fakultas","kampus"));
});

Route::get('/prodi',[ProdiController::class,"index"]);

