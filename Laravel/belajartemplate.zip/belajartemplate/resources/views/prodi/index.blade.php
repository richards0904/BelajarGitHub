@extends('layout.master')
@section('title',"Hal Prodi")

@section('content')
    <h2>Ini adalah halaman Prodi</h2>
@endsection
