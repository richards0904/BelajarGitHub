@extends('layout.master')
@section('title','Halaman Fakultas')

<ul>
@section('content')
    @foreach ($fakultas as $f)
        <li>{{$f}}</li>
    @endforeach
@endsection
</ul>

