<?php $__env->startSection('title','Halaman Fakultas'); ?>

<ul>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $fakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($f); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
</ul>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SI41\Laravel\belajartemplate\resources\views/fakultas/index.blade.php ENDPATH**/ ?>