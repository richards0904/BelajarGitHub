<?php $__env->startSection('title',"Hal Prodi"); ?>

<?php $__env->startSection('content'); ?>
    <h2>Ini adalah halaman Prodi</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\SI41\Laravel\belajartemplate\resources\views/prodi/index.blade.php ENDPATH**/ ?>